INSERT INTO TEACHERS (id, last_name, first_name) VALUES (1, 'Dupont', 'Paul');
